export function NoteTxt({ note }) {
    return (
        <article className="note-txt">
            {note.info.txt}
        </article>
    )
}