export function NoteToDo({ note }) {
    const todoList = note.info.todo
    return (
        <ul>

        </ul>
    )
}