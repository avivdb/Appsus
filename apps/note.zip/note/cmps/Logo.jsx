export function Logo() {
    return (
        <section className="logo">
            Miss.Keep
        </section>
    )
}